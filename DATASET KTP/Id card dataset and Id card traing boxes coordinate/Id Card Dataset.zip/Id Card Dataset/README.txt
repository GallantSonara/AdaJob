source of the origin dataset: https://www.kaggle.com/datasets/omrastogi/identity-card-dataset

and some other from the internet